# SoundMaster - Analyseur Audio Professionnel

Application d'analyse audio avec IA qui agit comme un ingénieur du son.

## Fonctionnalités
- Analyse spectrale avec spectrogramme 3D
- Analyse loudness (LUFS, Peak, Headroom, Dynamic Range)
- Analyse stéréo (Corrélation, Width, Balance)
- Recommandations IA personnalisées (GPT-5.2)
- Chat avec assistant ingénieur son
- Glossaire des termes audio
- Export PDF des rapports

## Installation

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001
```

### Frontend
```bash
cd frontend
yarn install
yarn start
```

## Technologies
- Frontend: React, Plotly.js, Lucide Icons
- Backend: FastAPI, Librosa, NumPy
- IA: OpenAI GPT-5.2
- Database: MongoDB
