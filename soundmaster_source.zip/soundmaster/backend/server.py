from fastapi import FastAPI, APIRouter, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Dict, Optional
import uuid
from datetime import datetime, timezone
import numpy as np
import tempfile
import io

# Audio processing
import librosa
import scipy.signal as signal

# PDF generation
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT

# LLM for recommendations
from emergentintegrations.llm.chat import LlmChat, UserMessage

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# LLM Key
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY')

app = FastAPI()
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Models
class FrequencyBand(BaseModel):
    range_hz: str
    energy_db: float
    peak_freq: float

class LoudnessAnalysis(BaseModel):
    rms_db: float
    peak_db: float
    lufs_estimate: float
    dynamic_range_db: float
    crest_factor_db: float
    headroom_db: float

class StereoAnalysis(BaseModel):
    is_stereo: bool
    correlation: float
    width: float
    balance: float
    mid_energy_db: Optional[float] = None
    side_energy_db: Optional[float] = None
    note: Optional[str] = None

class AnalysisResult(BaseModel):
    id: str
    filename: str
    duration: float
    sample_rate: int
    channels: int
    frequency_analysis: Dict[str, FrequencyBand]
    loudness_analysis: LoudnessAnalysis
    stereo_analysis: StereoAnalysis
    recommendations: List[str]
    overall_score: int
    status: str
    spectrogram_3d: Optional[Dict] = None  # 3D spectrogram data

# Audio Analysis Functions
def generate_3d_spectrogram(y: np.ndarray, sr: int, max_time_points: int = 100, max_freq_points: int = 60) -> Dict:
    """Generate 3D spectrogram data for visualization"""
    # Compute spectrogram
    n_fft = 2048
    hop_length = len(y) // max_time_points if len(y) > max_time_points else 512
    hop_length = max(512, hop_length)
    
    D = np.abs(librosa.stft(y, n_fft=n_fft, hop_length=hop_length))
    
    # Convert to dB
    D_db = librosa.amplitude_to_db(D, ref=np.max)
    
    # Get frequencies
    freqs = librosa.fft_frequencies(sr=sr, n_fft=n_fft)
    
    # Filter to audible range and downsample
    freq_mask = (freqs >= 20) & (freqs <= 20000)
    freqs_filtered = freqs[freq_mask]
    D_filtered = D_db[freq_mask, :]
    
    # Downsample frequencies if needed
    if len(freqs_filtered) > max_freq_points:
        indices = np.linspace(0, len(freqs_filtered) - 1, max_freq_points, dtype=int)
        freqs_filtered = freqs_filtered[indices]
        D_filtered = D_filtered[indices, :]
    
    # Downsample time if needed
    if D_filtered.shape[1] > max_time_points:
        indices = np.linspace(0, D_filtered.shape[1] - 1, max_time_points, dtype=int)
        D_filtered = D_filtered[:, indices]
    
    # Normalize to 0-1 range for visualization
    D_normalized = (D_filtered - D_filtered.min()) / (D_filtered.max() - D_filtered.min() + 1e-10)
    
    # Create time axis
    duration = len(y) / sr
    times = np.linspace(0, duration, D_filtered.shape[1])
    
    return {
        "times": times.tolist(),
        "frequencies": freqs_filtered.tolist(),
        "amplitudes": D_normalized.tolist(),  # 2D array [freq_index][time_index]
        "duration": duration,
        "freq_min": float(freqs_filtered.min()),
        "freq_max": float(freqs_filtered.max())
    }

def analyze_frequency_bands(y: np.ndarray, sr: int) -> Dict[str, FrequencyBand]:
    """Analyze frequency content in different bands"""
    bands = {
        'sub_bass': (20, 60),
        'bass': (60, 250),
        'low_mids': (250, 500),
        'mids': (500, 2000),
        'high_mids': (2000, 4000),
        'highs': (4000, 8000),
        'air': (8000, 20000)
    }
    
    # Compute FFT
    n_fft = 4096
    D = np.abs(librosa.stft(y, n_fft=n_fft))
    freqs = librosa.fft_frequencies(sr=sr, n_fft=n_fft)
    
    # Average power across time
    power = np.mean(D ** 2, axis=1)
    
    result = {}
    for band_name, (low, high) in bands.items():
        # Find frequency indices
        idx = np.where((freqs >= low) & (freqs <= high))[0]
        if len(idx) > 0:
            band_power = power[idx]
            energy_db = 10 * np.log10(np.mean(band_power) + 1e-10)
            peak_idx = idx[np.argmax(band_power)]
            peak_freq = freqs[peak_idx]
        else:
            energy_db = -60.0
            peak_freq = (low + high) / 2
        
        result[band_name] = FrequencyBand(
            range_hz=f"{low}-{high}",
            energy_db=round(energy_db, 2),
            peak_freq=round(peak_freq, 1)
        )
    
    return result

def analyze_loudness(y: np.ndarray, sr: int) -> LoudnessAnalysis:
    """Analyze loudness metrics"""
    # RMS
    rms = np.sqrt(np.mean(y ** 2))
    rms_db = 20 * np.log10(rms + 1e-10)
    
    # Peak
    peak = np.max(np.abs(y))
    peak_db = 20 * np.log10(peak + 1e-10)
    
    # Headroom
    headroom_db = -peak_db
    
    # LUFS estimate (simplified)
    lufs_estimate = rms_db - 0.691
    
    # Dynamic range (difference between loud and quiet parts)
    # Adjust frame_length based on audio length to handle short files
    audio_length = len(y)
    ideal_frame_length = int(sr * 0.4)  # 400ms frames
    
    # Ensure frame_length is at most 1/4 of audio length and at least 256 samples
    frame_length = min(ideal_frame_length, max(256, audio_length // 4))
    hop_length = max(64, frame_length // 4)
    
    dynamic_range_db = 0.0
    if audio_length > frame_length:
        try:
            frames = librosa.util.frame(y, frame_length=frame_length, hop_length=hop_length)
            frame_rms = np.sqrt(np.mean(frames ** 2, axis=0))
            frame_db = 20 * np.log10(frame_rms + 1e-10)
            
            # Remove very quiet frames (below -60dB)
            valid_frames = frame_db[frame_db > -60]
            if len(valid_frames) > 1:
                dynamic_range_db = np.percentile(valid_frames, 95) - np.percentile(valid_frames, 5)
        except Exception:
            pass  # Keep dynamic_range_db = 0.0 for very short files
    
    # Crest factor
    crest_factor_db = peak_db - rms_db
    
    return LoudnessAnalysis(
        rms_db=round(rms_db, 2),
        peak_db=round(peak_db, 2),
        lufs_estimate=round(lufs_estimate, 2),
        dynamic_range_db=round(dynamic_range_db, 2),
        crest_factor_db=round(crest_factor_db, 2),
        headroom_db=round(headroom_db, 2)
    )

def analyze_stereo(y: np.ndarray, sr: int) -> StereoAnalysis:
    """Analyze stereo field"""
    if y.ndim == 1:
        return StereoAnalysis(
            is_stereo=False,
            correlation=1.0,
            width=0.0,
            balance=0.0,
            note="Fichier mono - pas d'analyse stéréo disponible"
        )
    
    left = y[0]
    right = y[1]
    
    # Mid/Side
    mid = (left + right) / 2
    side = (left - right) / 2
    
    mid_energy = np.mean(mid ** 2)
    side_energy = np.mean(side ** 2)
    
    mid_energy_db = 10 * np.log10(mid_energy + 1e-10)
    side_energy_db = 10 * np.log10(side_energy + 1e-10)
    
    # Correlation
    correlation = np.corrcoef(left, right)[0, 1]
    if np.isnan(correlation):
        correlation = 1.0
    
    # Width (based on side/mid ratio)
    if mid_energy > 0:
        width = np.sqrt(side_energy / (mid_energy + side_energy))
    else:
        width = 0.0
    
    # Balance
    left_energy = np.mean(left ** 2)
    right_energy = np.mean(right ** 2)
    total_energy = left_energy + right_energy
    if total_energy > 0:
        balance = (right_energy - left_energy) / total_energy
    else:
        balance = 0.0
    
    return StereoAnalysis(
        is_stereo=True,
        correlation=round(correlation, 3),
        width=round(width, 3),
        balance=round(balance, 3),
        mid_energy_db=round(mid_energy_db, 2),
        side_energy_db=round(side_energy_db, 2)
    )

def calculate_overall_score(freq_analysis: Dict, loudness: LoudnessAnalysis, stereo: StereoAnalysis) -> int:
    """Calculate overall quality score"""
    score = 100
    
    # Loudness penalties
    if loudness.headroom_db < 1:
        score -= 15  # Too loud / clipping risk
    elif loudness.headroom_db < 3:
        score -= 5
    
    if loudness.dynamic_range_db < 5:
        score -= 10  # Over-compressed
    elif loudness.dynamic_range_db < 8:
        score -= 5
    
    # Frequency balance penalties
    sub_bass_db = freq_analysis['sub_bass'].energy_db
    bass_db = freq_analysis['bass'].energy_db
    mids_db = freq_analysis['mids'].energy_db
    highs_db = freq_analysis['highs'].energy_db
    
    # Check for muddy bass
    if bass_db > mids_db + 6:
        score -= 10
    
    # Check for harsh highs
    if highs_db > mids_db + 3:
        score -= 5
    
    # Check for weak highs
    if highs_db < mids_db - 12:
        score -= 5
    
    # Stereo penalties
    if stereo.is_stereo:
        if stereo.correlation < 0.3:
            score -= 10  # Phase issues
        if abs(stereo.balance) > 0.2:
            score -= 5  # Unbalanced
    
    return max(0, min(100, score))

async def generate_recommendations(
    freq_analysis: Dict, 
    loudness: LoudnessAnalysis, 
    stereo: StereoAnalysis,
    filename: str
) -> List[str]:
    """Generate AI recommendations based on analysis"""
    
    # Build analysis summary for LLM
    analysis_summary = f"""
Fichier: {filename}

ANALYSE DE LOUDNESS:
- RMS: {loudness.rms_db} dB
- Peak: {loudness.peak_db} dB  
- LUFS estimé: {loudness.lufs_estimate}
- Headroom: {loudness.headroom_db} dB
- Plage dynamique: {loudness.dynamic_range_db} dB
- Facteur de crête: {loudness.crest_factor_db} dB

ANALYSE SPECTRALE:
- Sub Bass (20-60Hz): {freq_analysis['sub_bass'].energy_db} dB
- Bass (60-250Hz): {freq_analysis['bass'].energy_db} dB
- Low Mids (250-500Hz): {freq_analysis['low_mids'].energy_db} dB
- Mids (500-2kHz): {freq_analysis['mids'].energy_db} dB
- High Mids (2-4kHz): {freq_analysis['high_mids'].energy_db} dB
- Highs (4-8kHz): {freq_analysis['highs'].energy_db} dB
- Air (8-20kHz): {freq_analysis['air'].energy_db} dB

ANALYSE STÉRÉO:
- Stéréo: {'Oui' if stereo.is_stereo else 'Non (Mono)'}
- Corrélation: {stereo.correlation}
- Largeur: {stereo.width}
- Balance L/R: {stereo.balance}
"""

    try:
        chat = LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=f"soundmaster-{uuid.uuid4()}",
            system_message="""Tu es un ingénieur du son professionnel expert en mixage et mastering. 
Analyse les données audio fournies et donne 4-6 recommandations concrètes et actionnables pour améliorer le mix.
Sois précis et technique mais accessible. Utilise des termes français.
Chaque recommandation doit être une phrase complète et spécifique au problème détecté.
Ne numérote pas tes recommandations, retourne-les séparées par des sauts de ligne."""
        ).with_model("openai", "gpt-5.2")
        
        user_message = UserMessage(
            text=f"Analyse ce fichier audio et donne-moi des recommandations de mixage:\n{analysis_summary}"
        )
        
        response = await chat.send_message(user_message)
        
        # Parse recommendations
        recommendations = [r.strip() for r in response.strip().split('\n') if r.strip() and len(r.strip()) > 10]
        return recommendations[:6]
        
    except Exception as e:
        logger.error(f"LLM error: {e}")
        # Fallback recommendations based on analysis
        recommendations = []
        
        if loudness.headroom_db < 1:
            recommendations.append("Le mix est trop fort et risque de clipper. Réduisez le gain du master de 2-3 dB pour garder du headroom.")
        
        if loudness.dynamic_range_db < 6:
            recommendations.append("La plage dynamique est faible, le mix semble sur-compressé. Réduisez le ratio de compression sur le bus master.")
        
        if freq_analysis['bass'].energy_db > freq_analysis['mids'].energy_db + 6:
            recommendations.append("Les basses sont trop présentes par rapport aux médiums. Appliquez un cut EQ vers 200-300Hz pour réduire la boue.")
        
        if freq_analysis['highs'].energy_db > freq_analysis['mids'].energy_db + 3:
            recommendations.append("Les aigus sont trop agressifs. Adoucissez avec un shelf EQ high vers -2dB à partir de 6kHz.")
        
        if stereo.is_stereo and stereo.correlation < 0.5:
            recommendations.append("La corrélation stéréo est faible, ce qui peut causer des problèmes en mono. Vérifiez la phase de vos pistes.")
        
        if stereo.is_stereo and abs(stereo.balance) > 0.15:
            direction = "droite" if stereo.balance > 0 else "gauche"
            recommendations.append(f"Le mix penche vers la {direction}. Rééquilibrez les panoramiques pour centrer l'image stéréo.")
        
        if not recommendations:
            recommendations.append("Le mix semble bien équilibré. Continuez à affiner les détails et faites des pauses d'écoute régulières.")
        
        return recommendations

@api_router.get("/")
async def root():
    return {"message": "SoundMaster API - Audio Analysis Service"}

@api_router.post("/analyze", response_model=AnalysisResult)
async def analyze_audio(file: UploadFile = File(...)):
    """Analyze an audio file and return professional recommendations"""
    
    # Validate file type
    filename = file.filename.lower()
    if not (filename.endswith('.wav') or filename.endswith('.mp3')):
        raise HTTPException(status_code=400, detail="Format non supporté. Utilisez WAV ou MP3.")
    
    try:
        # Read file content
        content = await file.read()
        
        # Save to temp file for librosa
        with tempfile.NamedTemporaryFile(suffix=Path(filename).suffix, delete=False) as tmp:
            tmp.write(content)
            tmp_path = tmp.name
        
        try:
            # Load audio with librosa
            y, sr = librosa.load(tmp_path, sr=None, mono=False)
            
            # Get duration
            if y.ndim == 1:
                duration = len(y) / sr
                channels = 1
                y_mono = y
            else:
                duration = y.shape[1] / sr
                channels = y.shape[0]
                y_mono = librosa.to_mono(y)
            
            # Perform analysis
            freq_analysis = analyze_frequency_bands(y_mono, sr)
            loudness = analyze_loudness(y_mono, sr)
            stereo = analyze_stereo(y, sr)
            
            # Generate 3D spectrogram data
            spectrogram_3d = generate_3d_spectrogram(y_mono, sr)
            
            # Calculate score
            overall_score = calculate_overall_score(freq_analysis, loudness, stereo)
            
            # Generate AI recommendations
            recommendations = await generate_recommendations(
                freq_analysis, loudness, stereo, file.filename
            )
            
            # Create result
            analysis_id = str(uuid.uuid4())
            result = AnalysisResult(
                id=analysis_id,
                filename=file.filename,
                duration=round(duration, 2),
                sample_rate=sr,
                channels=channels,
                frequency_analysis={k: v.model_dump() for k, v in freq_analysis.items()},
                loudness_analysis=loudness,
                stereo_analysis=stereo,
                recommendations=recommendations,
                overall_score=overall_score,
                status="completed",
                spectrogram_3d=spectrogram_3d
            )
            
            # Save to database
            doc = result.model_dump()
            doc['created_at'] = datetime.now(timezone.utc).isoformat()
            await db.audio_analyses.insert_one(doc)
            
            return result
            
        finally:
            # Cleanup temp file
            os.unlink(tmp_path)
            
    except Exception as e:
        logger.error(f"Analysis error: {e}")
        raise HTTPException(status_code=500, detail=f"Erreur lors de l'analyse: {str(e)}")

@api_router.get("/analyses", response_model=List[AnalysisResult])
async def get_analyses():
    """Get all previous analyses"""
    analyses = await db.audio_analyses.find({}, {"_id": 0}).to_list(100)
    return analyses

class ChatMessage(BaseModel):
    message: str
    context: Optional[str] = None  # Optional analysis context

class ChatResponse(BaseModel):
    response: str

@api_router.post("/chat", response_model=ChatResponse)
async def chat_with_ai(chat: ChatMessage):
    """Chat with the AI sound engineer"""
    try:
        system_prompt = """Tu es un ingénieur du son professionnel avec 20 ans d'expérience en studio d'enregistrement, mixage et mastering.
Tu réponds aux questions sur la production musicale, le mixage, le mastering, l'acoustique, les équipements audio, etc.
Sois précis, technique mais accessible. Utilise des termes français.
Si on te pose une question hors sujet (non liée à l'audio/musique), réponds poliment que tu es spécialisé en ingénierie du son.
Donne des conseils pratiques et des exemples concrets quand c'est pertinent."""

        if chat.context:
            system_prompt += f"\n\nContexte de l'analyse en cours:\n{chat.context}"

        llm = LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=f"soundmaster-chat-{uuid.uuid4()}",
            system_message=system_prompt
        ).with_model("openai", "gpt-5.2")
        
        user_message = UserMessage(text=chat.message)
        response = await llm.send_message(user_message)
        
        return ChatResponse(response=response.strip())
        
    except Exception as e:
        logger.error(f"Chat error: {e}")
        raise HTTPException(status_code=500, detail=f"Erreur du chat IA: {str(e)}")

@api_router.get("/download-source")
async def download_source_code():
    """Download the complete source code as ZIP"""
    import zipfile
    
    # Create ZIP in memory
    buffer = io.BytesIO()
    
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        # Add backend files
        zf.write('/app/backend/server.py', 'soundmaster/backend/server.py')
        zf.write('/app/backend/.env', 'soundmaster/backend/.env')
        zf.write('/app/backend/requirements.txt', 'soundmaster/backend/requirements.txt')
        
        # Add frontend files
        zf.write('/app/frontend/src/App.js', 'soundmaster/frontend/src/App.js')
        zf.write('/app/frontend/src/App.css', 'soundmaster/frontend/src/App.css')
        zf.write('/app/frontend/src/components/Spectrogram3D.js', 'soundmaster/frontend/src/components/Spectrogram3D.js')
        zf.write('/app/frontend/package.json', 'soundmaster/frontend/package.json')
        
        # Add README
        readme_content = """# SoundMaster - Analyseur Audio Professionnel

Application d'analyse audio avec IA qui agit comme un ingénieur du son.

## Fonctionnalités
- Analyse spectrale avec spectrogramme 3D
- Analyse loudness (LUFS, Peak, Headroom, Dynamic Range)
- Analyse stéréo (Corrélation, Width, Balance)
- Recommandations IA personnalisées (GPT-5.2)
- Chat avec assistant ingénieur son
- Glossaire des termes audio
- Export PDF des rapports

## Installation

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001
```

### Frontend
```bash
cd frontend
yarn install
yarn start
```

## Technologies
- Frontend: React, Plotly.js, Lucide Icons
- Backend: FastAPI, Librosa, NumPy
- IA: OpenAI GPT-5.2
- Database: MongoDB
"""
        zf.writestr('soundmaster/README.md', readme_content)
    
    buffer.seek(0)
    
    return StreamingResponse(
        buffer,
        media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=soundmaster_source.zip"}
    )

@api_router.get("/export-pdf/{analysis_id}")
async def export_pdf(analysis_id: str):
    """Export analysis results as PDF"""
    
    # Get analysis from database
    analysis = await db.audio_analyses.find_one({"id": analysis_id}, {"_id": 0})
    if not analysis:
        raise HTTPException(status_code=404, detail="Analyse non trouvée")
    
    # Create PDF in memory
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=20*mm, bottomMargin=20*mm)
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle('Title', parent=styles['Title'], fontSize=24, textColor=colors.HexColor('#6C63FF'), spaceAfter=20)
    heading_style = ParagraphStyle('Heading', parent=styles['Heading2'], fontSize=14, textColor=colors.HexColor('#6C63FF'), spaceBefore=15, spaceAfter=10)
    normal_style = ParagraphStyle('Normal', parent=styles['Normal'], fontSize=10, spaceAfter=5)
    rec_style = ParagraphStyle('Recommendation', parent=styles['Normal'], fontSize=10, leftIndent=20, spaceAfter=8)
    
    elements = []
    
    # Title
    elements.append(Paragraph("SoundMaster - Rapport d'Analyse", title_style))
    elements.append(Spacer(1, 10))
    
    # File info
    elements.append(Paragraph("Informations du fichier", heading_style))
    info_data = [
        ["Fichier:", analysis['filename']],
        ["Durée:", f"{analysis['duration']:.1f} secondes"],
        ["Sample Rate:", f"{analysis['sample_rate']} Hz"],
        ["Canaux:", "Stéréo" if analysis['channels'] > 1 else "Mono"],
        ["Score Global:", f"{analysis['overall_score']}/100"],
    ]
    info_table = Table(info_data, colWidths=[100, 300])
    info_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.gray),
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('ALIGN', (1, 0), (1, -1), 'LEFT'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    elements.append(info_table)
    
    # Loudness Analysis
    elements.append(Paragraph("Analyse Loudness", heading_style))
    loudness = analysis['loudness_analysis']
    loudness_data = [
        ["LUFS estimé:", f"{loudness['lufs_estimate']:.1f}"],
        ["Peak:", f"{loudness['peak_db']:.1f} dB"],
        ["RMS:", f"{loudness['rms_db']:.1f} dB"],
        ["Headroom:", f"{loudness['headroom_db']:.1f} dB"],
        ["Plage Dynamique:", f"{loudness['dynamic_range_db']:.1f} dB"],
        ["Facteur de Crête:", f"{loudness['crest_factor_db']:.1f} dB"],
    ]
    loudness_table = Table(loudness_data, colWidths=[120, 100])
    loudness_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.gray),
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    elements.append(loudness_table)
    
    # Frequency Analysis
    elements.append(Paragraph("Analyse Spectrale", heading_style))
    band_labels = {
        'sub_bass': 'Sub Bass (20-60Hz)',
        'bass': 'Bass (60-250Hz)',
        'low_mids': 'Low Mids (250-500Hz)',
        'mids': 'Mids (500-2kHz)',
        'high_mids': 'High Mids (2-4kHz)',
        'highs': 'Highs (4-8kHz)',
        'air': 'Air (8-20kHz)',
    }
    freq_data = []
    for band, data in analysis['frequency_analysis'].items():
        label = band_labels.get(band, band)
        freq_data.append([label, f"{data['energy_db']:.1f} dB"])
    
    freq_table = Table(freq_data, colWidths=[150, 80])
    freq_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.gray),
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('ALIGN', (1, 0), (1, -1), 'LEFT'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    elements.append(freq_table)
    
    # Stereo Analysis
    elements.append(Paragraph("Analyse Stéréo", heading_style))
    stereo = analysis['stereo_analysis']
    if stereo['is_stereo']:
        stereo_data = [
            ["Corrélation:", f"{stereo['correlation']*100:.0f}%"],
            ["Largeur Stéréo:", f"{stereo['width']*100:.0f}%"],
            ["Balance L/R:", f"{abs(stereo['balance'])*100:.0f}% {'R' if stereo['balance'] > 0 else 'L' if stereo['balance'] < 0 else ''}"],
        ]
        stereo_table = Table(stereo_data, colWidths=[120, 100])
        stereo_table.setStyle(TableStyle([
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.gray),
            ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(stereo_table)
    else:
        elements.append(Paragraph("Fichier mono - pas d'analyse stéréo disponible", normal_style))
    
    # Recommendations
    elements.append(Paragraph("Recommandations IA", heading_style))
    for i, rec in enumerate(analysis['recommendations'], 1):
        elements.append(Paragraph(f"<b>{i}.</b> {rec}", rec_style))
    
    # Footer
    elements.append(Spacer(1, 30))
    footer_style = ParagraphStyle('Footer', parent=styles['Normal'], fontSize=8, textColor=colors.gray, alignment=TA_CENTER)
    elements.append(Paragraph(f"Généré par SoundMaster - {datetime.now().strftime('%d/%m/%Y %H:%M')}", footer_style))
    
    # Build PDF
    doc.build(elements)
    buffer.seek(0)
    
    # Return PDF as download
    filename_safe = analysis['filename'].rsplit('.', 1)[0]
    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=SoundMaster_{filename_safe}.pdf"}
    )

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
