import React, { useState, useCallback, useRef, useEffect } from 'react';
import './App.css';
import axios from 'axios';
import { Upload, Music, Activity, Volume2, Headphones, Lightbulb, FileAudio, AlertCircle, Download, Info, BarChart3, AudioWaveform, MessageSquare, Bot, BookOpen, Send } from 'lucide-react';
import Spectrogram3D from './components/Spectrogram3D';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Glossaire des termes audio
const GLOSSARY = {
  composition: {
    title: "Composition",
    terms: [
      { term: "BPM", def: "Beats Per Minute - Tempo d'un morceau, nombre de battements par minute" },
      { term: "Mélodie", def: "Suite de notes formant une ligne musicale reconnaissable" },
      { term: "Harmonie", def: "Combinaison de notes jouées simultanément (accords)" },
      { term: "Progression d'accords", def: "Séquence d'accords qui forme la structure harmonique" },
      { term: "Hook", def: "Élément accrocheur et mémorable d'un morceau" },
      { term: "Bridge", def: "Section de transition entre couplet et refrain" },
      { term: "Drop", def: "Moment d'impact où tous les éléments entrent ensemble (EDM)" },
    ]
  },
  arrangement: {
    title: "Arrangement",
    terms: [
      { term: "Layering", def: "Superposition de sons pour créer de la richesse" },
      { term: "Build-up", def: "Montée en tension avant un drop ou refrain" },
      { term: "Breakdown", def: "Section épurée avec moins d'éléments" },
      { term: "Pad", def: "Nappe sonore qui remplit l'espace harmonique" },
      { term: "Arpège", def: "Notes d'un accord jouées successivement" },
      { term: "Contrepoint", def: "Lignes mélodiques indépendantes qui s'entrelacent" },
    ]
  },
  enregistrement: {
    title: "Enregistrement",
    terms: [
      { term: "Sample Rate", def: "Fréquence d'échantillonnage (44.1kHz, 48kHz, 96kHz)" },
      { term: "Bit Depth", def: "Résolution audio (16-bit, 24-bit, 32-bit)" },
      { term: "Gain staging", def: "Gestion des niveaux à chaque étape du signal" },
      { term: "DI", def: "Direct Input - Enregistrement direct sans micro" },
      { term: "Overhead", def: "Micros placés au-dessus (batterie notamment)" },
      { term: "Room mic", def: "Micro d'ambiance captant la réverbération naturelle" },
      { term: "Proximity effect", def: "Augmentation des basses quand le micro est proche" },
    ]
  },
  mixage: {
    title: "Mixage",
    terms: [
      { term: "EQ (Égalisation)", def: "Ajustement des fréquences d'un son" },
      { term: "Compression", def: "Réduction de la dynamique, contrôle des pics" },
      { term: "Ratio", def: "Taux de compression (ex: 4:1)" },
      { term: "Threshold", def: "Seuil à partir duquel le compresseur agit" },
      { term: "Attack/Release", def: "Temps de réaction du compresseur" },
      { term: "Reverb", def: "Simulation de l'acoustique d'un espace" },
      { term: "Delay", def: "Répétition retardée du signal (écho)" },
      { term: "Sidechain", def: "Déclenchement d'un effet par un autre signal" },
      { term: "Bus/Groupe", def: "Regroupement de pistes pour traitement commun" },
      { term: "Pan", def: "Positionnement gauche/droite dans l'image stéréo" },
      { term: "Send/Return", def: "Envoi vers un effet en parallèle" },
      { term: "High-pass filter (HPF)", def: "Filtre qui coupe les basses fréquences" },
      { term: "Low-pass filter (LPF)", def: "Filtre qui coupe les hautes fréquences" },
      { term: "Saturation", def: "Distorsion harmonique légère ajoutant de la chaleur" },
    ]
  },
  mastering: {
    title: "Mastering",
    terms: [
      { term: "LUFS", def: "Loudness Units Full Scale - Mesure de volume perçu" },
      { term: "True Peak", def: "Niveau de crête réel incluant l'inter-sample" },
      { term: "Headroom", def: "Marge entre le niveau max et 0 dBFS" },
      { term: "Limiter", def: "Compresseur avec ratio infini, empêche le clipping" },
      { term: "Dithering", def: "Bruit ajouté lors de la réduction de bit depth" },
      { term: "Mid/Side", def: "Traitement séparé du centre et des côtés stéréo" },
      { term: "Stereo Width", def: "Largeur de l'image stéréo" },
      { term: "Dynamic Range", def: "Écart entre les passages forts et faibles" },
      { term: "Clipping", def: "Distorsion quand le signal dépasse 0 dBFS" },
      { term: "Loudness War", def: "Course au volume excessif nuisant à la qualité" },
    ]
  },
  frequences: {
    title: "Fréquences",
    terms: [
      { term: "Sub-bass (20-60Hz)", def: "Graves profondes, ressenties plus qu'entendues" },
      { term: "Bass (60-250Hz)", def: "Fondamentales de la basse et du kick" },
      { term: "Low-mids (250-500Hz)", def: "Zone souvent boueuse, à traiter avec soin" },
      { term: "Mids (500Hz-2kHz)", def: "Corps des instruments, voix" },
      { term: "High-mids (2-4kHz)", def: "Présence, intelligibilité de la voix" },
      { term: "Highs (4-8kHz)", def: "Brillance, attaque des cymbales" },
      { term: "Air (8-20kHz)", def: "Souffle, ouverture, shimmer" },
    ]
  }
};

function App() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  
  // Chat state
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatEndRef = useRef(null);
  
  // Glossary state
  const [selectedCategory, setSelectedCategory] = useState('composition');

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleFileSelect = useCallback(async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const fileName = file.name.toLowerCase();
    if (!fileName.endsWith('.wav') && !fileName.endsWith('.mp3')) {
      setError('Format non supporté. Veuillez sélectionner un fichier WAV ou MP3.');
      return;
    }

    setSelectedFile(file.name);
    setError(null);
    setIsAnalyzing(true);
    setUploadProgress(0);
    setAnalysisResult(null);
    setActiveTab(0);

    try {
      const formData = new FormData();
      formData.append('file', file);
      setUploadProgress(10);

      const response = await axios.post(`${API}/analyze`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          if (progressEvent.total) {
            const progress = Math.round((progressEvent.loaded * 60) / progressEvent.total) + 10;
            setUploadProgress(Math.min(progress, 70));
          }
        },
        timeout: 120000,
      });

      setUploadProgress(100);
      setAnalysisResult(response.data);
    } catch (err) {
      console.error('Analysis error:', err);
      const message = err.response?.data?.detail || err.message || 'Erreur inconnue';
      setError(message);
    } finally {
      setIsAnalyzing(false);
    }
  }, []);

  const sendChatMessage = useCallback(async () => {
    if (!chatInput.trim() || isChatLoading) return;
    
    const userMessage = chatInput.trim();
    setChatInput('');
    setChatMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsChatLoading(true);
    
    try {
      // Build context from current analysis if available
      let context = null;
      if (analysisResult) {
        context = `Fichier analysé: ${analysisResult.filename}
Score: ${analysisResult.overall_score}/100
LUFS: ${analysisResult.loudness_analysis.lufs_estimate}
Headroom: ${analysisResult.loudness_analysis.headroom_db} dB
Dynamic Range: ${analysisResult.loudness_analysis.dynamic_range_db} dB`;
      }
      
      const response = await axios.post(`${API}/chat`, {
        message: userMessage,
        context: context
      });
      
      setChatMessages(prev => [...prev, { role: 'assistant', content: response.data.response }]);
    } catch (err) {
      setChatMessages(prev => [...prev, { 
        role: 'assistant', 
        content: "Désolé, une erreur s'est produite. Réessayez." 
      }]);
    } finally {
      setIsChatLoading(false);
    }
  }, [chatInput, isChatLoading, analysisResult]);

  const getScoreColor = (score) => {
    if (score >= 80) return '#4CAF50';
    if (score >= 60) return '#FFC107';
    if (score >= 40) return '#FF9800';
    return '#F44336';
  };

  const getDbColor = (db, type) => {
    if (type === 'headroom') {
      if (db >= 3) return '#4CAF50';
      if (db >= 1) return '#FFC107';
      return '#F44336';
    }
    if (type === 'dynamic') {
      if (db >= 8) return '#4CAF50';
      if (db >= 5) return '#FFC107';
      return '#FF9800';
    }
    return '#64B5F6';
  };

  const handleExportPDF = useCallback(() => {
    if (analysisResult?.id) {
      window.open(`${API}/export-pdf/${analysisResult.id}`, '_blank');
    }
  }, [analysisResult]);

  const bandLabels = {
    'sub_bass': 'Sub Bass',
    'bass': 'Bass',
    'low_mids': 'Low Mids',
    'mids': 'Mids',
    'high_mids': 'High Mids',
    'highs': 'Highs',
    'air': 'Air',
  };

  const renderFrequencyBar = (band, data) => {
    const normalizedEnergy = Math.max(0, Math.min(100, (data.energy_db + 60) * 1.5));
    return (
      <div key={band} className="frequency-row" data-testid={`freq-band-${band}`}>
        <span className="band-label">{bandLabels[band] || band}</span>
        <div className="bar-container">
          <div className="bar" style={{ width: `${normalizedEnergy}%` }} />
        </div>
        <span className="db-value">{data.energy_db.toFixed(1)} dB</span>
      </div>
    );
  };

  const tabs = [
    { icon: Info, label: 'Détails' },
    { icon: BarChart3, label: 'Spectral' },
    { icon: AudioWaveform, label: 'Audio' },
    { icon: MessageSquare, label: 'Conseils' },
    { icon: Bot, label: 'IA' },
    { icon: BookOpen, label: 'Index' },
  ];

  // Tab 1: Analyse détaillée du fichier
  const renderDetailsTab = () => (
    <div className="tab-content" data-testid="tab-details">
      <div className="card score-card">
        <h2 className="section-title">Score Global</h2>
        <div className="score-circle">
          <span className="score-value" style={{ color: getScoreColor(analysisResult.overall_score) }}>
            {analysisResult.overall_score}
          </span>
          <span className="score-label">/100</span>
        </div>
      </div>

      <div className="card info-card">
        <h2 className="section-title">
          <FileAudio size={20} className="section-icon" />
          Informations du fichier
        </h2>
        <div className="info-row">
          <span className="info-label">Fichier:</span>
          <span className="info-value">{analysisResult.filename}</span>
        </div>
        <div className="info-row">
          <span className="info-label">Durée:</span>
          <span className="info-value">{analysisResult.duration.toFixed(1)}s</span>
        </div>
        <div className="info-row">
          <span className="info-label">Sample Rate:</span>
          <span className="info-value">{analysisResult.sample_rate} Hz</span>
        </div>
        <div className="info-row">
          <span className="info-label">Canaux:</span>
          <span className="info-value">{analysisResult.channels === 1 ? 'Mono' : 'Stéréo'}</span>
        </div>
      </div>

      <button className="export-pdf-btn" onClick={handleExportPDF} data-testid="export-pdf-btn">
        <Download size={20} />
        <span>Exporter le rapport PDF</span>
      </button>
    </div>
  );

  // Tab 2: Analyse spectrale
  const renderSpectralTab = () => (
    <div className="tab-content" data-testid="tab-spectral">
      <div className="card analysis-card">
        <h2 className="section-title">
          <Activity size={20} className="section-icon" />
          Spectrogramme 3D
        </h2>
        {analysisResult.spectrogram_3d && (
          <Spectrogram3D data={analysisResult.spectrogram_3d} />
        )}
      </div>

      <div className="card analysis-card">
        <h2 className="section-title">
          <BarChart3 size={20} className="section-icon" />
          Analyseur de fréquences
        </h2>
        <div className="spectrum-visualizer">
          {Object.entries(analysisResult.frequency_analysis).map(([band, data]) => {
            const normalizedHeight = Math.max(8, Math.min(100, (data.energy_db + 60) * 1.5));
            const bandNames = {
              'sub_bass': 'Sub', 'bass': 'Bass', 'low_mids': 'Low',
              'mids': 'Mid', 'high_mids': 'Hi-M', 'highs': 'High', 'air': 'Air',
            };
            return (
              <div key={band} className="spectrum-bar-container">
                <div className="spectrum-bar-wrapper">
                  <div className="spectrum-bar" style={{ height: `${normalizedHeight}%` }} />
                </div>
                <span className="spectrum-label">{bandNames[band]}</span>
                <span className="spectrum-db">{data.energy_db.toFixed(0)}</span>
              </div>
            );
          })}
        </div>
        <div className="frequency-details">
          {Object.entries(analysisResult.frequency_analysis).map(([band, data]) =>
            renderFrequencyBar(band, data)
          )}
        </div>
      </div>
    </div>
  );

  // Tab 3: Résultats audio
  const renderAudioTab = () => (
    <div className="tab-content" data-testid="tab-audio">
      <div className="card analysis-card">
        <h2 className="section-title">
          <Volume2 size={20} className="section-icon" />
          Analyse Loudness
        </h2>
        <div className="metrics-grid">
          <div className="metric-box">
            <span className="metric-label">LUFS</span>
            <span className="metric-value" style={{ color: '#64B5F6' }}>
              {analysisResult.loudness_analysis.lufs_estimate.toFixed(1)}
            </span>
          </div>
          <div className="metric-box">
            <span className="metric-label">Peak</span>
            <span className="metric-value" style={{ color: '#FF9800' }}>
              {analysisResult.loudness_analysis.peak_db.toFixed(1)} dB
            </span>
          </div>
          <div className="metric-box">
            <span className="metric-label">Headroom</span>
            <span className="metric-value" style={{ color: getDbColor(analysisResult.loudness_analysis.headroom_db, 'headroom') }}>
              {analysisResult.loudness_analysis.headroom_db.toFixed(1)} dB
            </span>
          </div>
          <div className="metric-box">
            <span className="metric-label">Dynamique</span>
            <span className="metric-value" style={{ color: getDbColor(analysisResult.loudness_analysis.dynamic_range_db, 'dynamic') }}>
              {analysisResult.loudness_analysis.dynamic_range_db.toFixed(1)} dB
            </span>
          </div>
        </div>
      </div>

      <div className="card analysis-card">
        <h2 className="section-title">
          <Headphones size={20} className="section-icon" />
          Image Stéréo
        </h2>
        {analysisResult.stereo_analysis.is_stereo ? (
          <div className="stereo-grid">
            <div className="stereo-item">
              <span className="stereo-label">Corrélation</span>
              <span className="stereo-value">{(analysisResult.stereo_analysis.correlation * 100).toFixed(0)}%</span>
              <div className="stereo-bar-bg">
                <div className="stereo-bar-fill" style={{ 
                  width: `${Math.abs(analysisResult.stereo_analysis.correlation) * 100}%`,
                  backgroundColor: analysisResult.stereo_analysis.correlation > 0 ? '#4CAF50' : '#F44336'
                }} />
              </div>
            </div>
            <div className="stereo-item">
              <span className="stereo-label">Largeur Stéréo</span>
              <span className="stereo-value">{(analysisResult.stereo_analysis.width * 100).toFixed(0)}%</span>
              <div className="stereo-bar-bg">
                <div className="stereo-bar-fill" style={{ 
                  width: `${analysisResult.stereo_analysis.width * 100}%`,
                  backgroundColor: '#6C63FF'
                }} />
              </div>
            </div>
            <div className="stereo-item">
              <span className="stereo-label">Balance L/R</span>
              <span className="stereo-value">
                {analysisResult.stereo_analysis.balance > 0 ? 'R ' : analysisResult.stereo_analysis.balance < 0 ? 'L ' : ''}
                {Math.abs(analysisResult.stereo_analysis.balance * 100).toFixed(0)}%
              </span>
              <div className="balance-bar-bg">
                <div className="balance-center" />
                <div className="balance-fill" style={{
                  left: analysisResult.stereo_analysis.balance < 0 
                    ? `${50 + analysisResult.stereo_analysis.balance * 50}%` 
                    : '50%',
                  width: `${Math.abs(analysisResult.stereo_analysis.balance) * 50}%`,
                }} />
              </div>
            </div>
          </div>
        ) : (
          <p className="mono-note">{analysisResult.stereo_analysis.note || "Fichier mono - pas d'analyse stéréo"}</p>
        )}
      </div>
    </div>
  );

  // Tab 4: Conseils
  const renderAdviceTab = () => (
    <div className="tab-content" data-testid="tab-advice">
      <div className="card recommendations-card">
        <h2 className="section-title">
          <Lightbulb size={20} className="section-icon recommendation-icon" />
          Recommandations IA
        </h2>
        <p className="advice-intro">
          Basé sur l'analyse de votre fichier, voici les corrections suggérées :
        </p>
        {analysisResult.recommendations.map((rec, index) => (
          <div key={index} className="recommendation-item" data-testid={`recommendation-${index}`}>
            <div className="rec-number"><span>{index + 1}</span></div>
            <p className="recommendation-text">{rec}</p>
          </div>
        ))}
      </div>
    </div>
  );

  // Tab 5: Chat IA
  const renderChatTab = () => (
    <div className="tab-content" data-testid="tab-chat">
      <div className="card chat-card">
        <h2 className="section-title">
          <Bot size={20} className="section-icon" />
          Assistant Ingénieur Son
        </h2>
        <p className="chat-intro">
          Posez vos questions sur le mixage, mastering, ou demandez des explications sur l'analyse.
        </p>
        
        <div className="chat-messages">
          {chatMessages.length === 0 && (
            <div className="chat-welcome">
              <Bot size={40} className="chat-welcome-icon" />
              <p>Bonjour ! Je suis votre assistant ingénieur du son. Comment puis-je vous aider ?</p>
              <div className="chat-suggestions">
                <button onClick={() => setChatInput("Comment améliorer mon mix ?")}>
                  Comment améliorer mon mix ?
                </button>
                <button onClick={() => setChatInput("Explique-moi le sidechain")}>
                  Explique-moi le sidechain
                </button>
                <button onClick={() => setChatInput("Quels plugins recommandes-tu ?")}>
                  Quels plugins recommandes-tu ?
                </button>
              </div>
            </div>
          )}
          
          {chatMessages.map((msg, index) => (
            <div key={index} className={`chat-message ${msg.role}`}>
              <div className="chat-message-content">
                {msg.content}
              </div>
            </div>
          ))}
          
          {isChatLoading && (
            <div className="chat-message assistant">
              <div className="chat-message-content typing">
                <span></span><span></span><span></span>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>
        
        <div className="chat-input-container">
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendChatMessage()}
            placeholder="Posez votre question..."
            className="chat-input"
            disabled={isChatLoading}
          />
          <button 
            onClick={sendChatMessage} 
            className="chat-send-btn"
            disabled={isChatLoading || !chatInput.trim()}
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );

  // Tab 6: Index/Glossaire
  const renderIndexTab = () => (
    <div className="tab-content" data-testid="tab-index">
      <div className="card glossary-card">
        <h2 className="section-title">
          <BookOpen size={20} className="section-icon" />
          Glossaire Audio
        </h2>
        <p className="glossary-intro">
          Tous les termes de la production musicale, de la composition au mastering.
        </p>
        
        <div className="glossary-categories">
          {Object.keys(GLOSSARY).map((cat) => (
            <button
              key={cat}
              className={`glossary-cat-btn ${selectedCategory === cat ? 'active' : ''}`}
              onClick={() => setSelectedCategory(cat)}
            >
              {GLOSSARY[cat].title}
            </button>
          ))}
        </div>
        
        <div className="glossary-terms">
          <h3 className="glossary-section-title">{GLOSSARY[selectedCategory].title}</h3>
          {GLOSSARY[selectedCategory].terms.map((item, index) => (
            <div key={index} className="glossary-item">
              <dt className="glossary-term">{item.term}</dt>
              <dd className="glossary-def">{item.def}</dd>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="app" data-testid="soundmaster-app">
      <div className="content">
        {/* Header */}
        <header className="header" data-testid="app-header">
          <Music size={48} className="header-icon" />
          <h1 className="title">SoundMaster</h1>
          <p className="subtitle">Analyseur Audio Professionnel</p>
        </header>

        {/* Upload Section */}
        <label className={`upload-button ${isAnalyzing ? 'disabled' : ''}`} data-testid="upload-button">
          <input
            type="file"
            accept=".wav,.mp3,audio/wav,audio/mpeg"
            onChange={handleFileSelect}
            disabled={isAnalyzing}
            style={{ display: 'none' }}
            data-testid="file-input"
          />
          {isAnalyzing ? (
            <div className="uploading-container">
              <div className="spinner" />
              <span className="uploading-text">Analyse en cours... {uploadProgress}%</span>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${uploadProgress}%` }} />
              </div>
            </div>
          ) : (
            <>
              <Upload size={48} className="upload-icon" />
              <span className="upload-text">Télécharger un fichier audio</span>
              <span className="upload-subtext">Formats supportés: WAV, MP3</span>
            </>
          )}
        </label>

        {/* Error Message */}
        {error && (
          <div className="error-message" data-testid="error-message">
            <AlertCircle size={20} />
            <span>{error}</span>
          </div>
        )}

        {/* Selected File */}
        {selectedFile && !isAnalyzing && !error && (
          <div className="selected-file" data-testid="selected-file">
            <FileAudio size={16} />
            <span>{selectedFile}</span>
          </div>
        )}

        {/* Results with Tabs */}
        {analysisResult && (
          <div className="results-container" data-testid="results-container">
            {/* Tab Navigation */}
            <div className="tabs-nav" data-testid="tabs-nav">
              {tabs.map((tab, index) => (
                <button
                  key={index}
                  className={`tab-btn ${activeTab === index ? 'active' : ''}`}
                  onClick={() => setActiveTab(index)}
                  data-testid={`tab-btn-${index}`}
                >
                  <tab.icon size={18} />
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="tab-panel">
              {activeTab === 0 && renderDetailsTab()}
              {activeTab === 1 && renderSpectralTab()}
              {activeTab === 2 && renderAudioTab()}
              {activeTab === 3 && renderAdviceTab()}
              {activeTab === 4 && renderChatTab()}
              {activeTab === 5 && renderIndexTab()}
            </div>
          </div>
        )}

        {/* Empty State */}
        {!analysisResult && !isAnalyzing && (
          <div className="empty-state" data-testid="empty-state">
            <Activity size={80} className="empty-icon" />
            <h2 className="empty-title">Prêt à analyser</h2>
            <p className="empty-text">
              Téléchargez un fichier WAV ou MP3 pour obtenir une analyse professionnelle
              de votre mix avec des recommandations personnalisées.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
